// ═══════════════════════════════════════════════════════════════════
//  Cosmic API - Node/Electron port of the original C# Cosmic backend.
//
//  Loaded by the host's plugin system when "Cosmic API" is toggled on.
//  The host calls activate(ctx) on enable and deactivate() on disable,
//  and routes the Attach button / Execute through the `executor` object.
//
//  Flow:
//    activate()            -> starts the WebSocket server on 127.0.0.1:24950
//    executor.attach()     -> downloads binaries (once) + injects Roblox
//    executor.execute(lua) -> broadcasts a Luau script to injected clients
// ═══════════════════════════════════════════════════════════════════
'use strict'

const http = require('http')
const crypto = require('crypto')
const fs = require('fs')
const path = require('path')
const { spawn, exec } = require('child_process')
const WebSocket = require('ws')

const WS_PORT = 24950
const DLL_URL = 'https://auth.cosmic.best/files/dll'
const INJ_URL = 'https://auth.cosmic.best/files/injector'
const SECURE_ENGINE_URL = 'https://auth.cosmic.best/files/secureengine'
const INFO_URL = 'https://auth.cosmic.best/info'

let ctx = null                    // host-provided context (log / emit / binDir)
let server = null                 // HTTP server used for the WS upgrade
let wss = null                    // ws.Server (noServer mode)
let initialized = false
const clients = new Map()         // pid -> WebSocket
let autoInject = false
let autoInjectTimer = null
let injectedPids = new Set()
let lastPids = new Set()

function log(kind, msg) { if (ctx && ctx.log) ctx.log(kind, '[Cosmic] ' + msg) }
function emit(event, data) { if (ctx && ctx.emit) ctx.emit(event, data) }
function binDir() { return (ctx && ctx.binDir) || path.join(process.cwd(), 'bin') }

// ── Binary download / verify ────────────────────────────────────────

function sha256File(p) {
    return new Promise((resolve, reject) => {
        const h = crypto.createHash('sha256')
        const s = fs.createReadStream(p)
        s.on('error', reject)
        s.on('data', d => h.update(d))
        s.on('end', () => resolve(h.digest('hex')))
    })
}

async function download(url, dest) {
    const res = await fetch(url)
    if (!res.ok) throw new Error(`download failed (${res.status}) ${url}`)
    fs.writeFileSync(dest, Buffer.from(await res.arrayBuffer()))
}

async function setup() {
    const bin = binDir()
    fs.mkdirSync(bin, { recursive: true })

    if (ctx.progress) ctx.progress(1, 4, 'Checking for updates...')
    let dllHash = null, injHash = null
    try {
        const info = await (await fetch(INFO_URL)).json()
        dllHash = info.dll_hash
        injHash = info.inj_hash
    } catch { /* offline / no info endpoint - fall back to existence checks */ }

    if (ctx.progress) ctx.progress(2, 4, 'Refreshing binaries...')
    const modulePath = path.join(bin, 'Module.dll')
    let needDll = !fs.existsSync(modulePath)
    if (!needDll && dllHash) needDll = (await sha256File(modulePath)) !== dllHash
    if (needDll) await download(DLL_URL, modulePath)

    const injPath = path.join(bin, 'Injector.exe')
    let needInj = !fs.existsSync(injPath)
    if (!needInj && injHash) needInj = (await sha256File(injPath)) !== injHash
    if (needInj) await download(INJ_URL, injPath)

    if (ctx.progress) ctx.progress(3, 4, 'Checking SecureEngine...')
    const sePath = path.join(bin, 'SecureEngineSDK64.dll')
    if (!fs.existsSync(sePath)) await download(SECURE_ENGINE_URL, sePath)

    if (ctx.progress) ctx.progress(4, 4, 'Ready!')
}

// ── WebSocket server ────────────────────────────────────────────────

function initialize() {
    if (initialized) return
    server = http.createServer((req, res) => { res.statusCode = 400; res.end() })
    wss = new WebSocket.Server({ noServer: true })

    server.on('upgrade', (req, socket, head) => {
        const pid = parseInt(req.headers['process-id'], 10)
        if (!pid) { socket.destroy(); return }
        wss.handleUpgrade(req, socket, head, (sock) => {
            clients.set(pid, sock)
            log('print', `Client connected (PID ${pid})`)
            emit('connected', { pid })
            sock.on('message', (data) => handleMessage(pid, data.toString()))
            sock.on('close', () => {
                clients.delete(pid)
                log('warn', `Client disconnected (PID ${pid})`)
                emit('disconnected', { pid })
            })
            sock.on('error', () => {})
        })
    })

    server.on('error', (e) => log('error', `Server error: ${e.message}`))
    server.listen(WS_PORT, '127.0.0.1', () => log('print', `Listening on 127.0.0.1:${WS_PORT}`))
    initialized = true
    startAutoInjectLoop()
}

function shutdown() {
    autoInject = false
    if (autoInjectTimer) { clearInterval(autoInjectTimer); autoInjectTimer = null }
    for (const sock of clients.values()) { try { sock.close() } catch {} }
    clients.clear()
    injectedPids.clear()
    try { wss && wss.close() } catch {}
    try { server && server.close() } catch {}
    server = null
    wss = null
    initialized = false
    log('warn', 'Cosmic API disabled.')
}

function handleMessage(pid, message) {
    if (!message || message[0] !== '{') return
    let obj
    try { obj = JSON.parse(message) } catch { return }

    // User/game info report.
    if (obj.UserId !== undefined && obj.GameId !== undefined) {
        emit('userinfo', { pid, userId: obj.UserId, gameId: obj.GameId })
        return
    }

    const kindFor = (s) => (s === 2 ? 'error' : s === 1 ? 'warn' : 'print')
    switch (obj.Type) {
        case 'Setting':
            emit('setting', { pid, name: obj.Name, value: obj.Value })
            break
        case 'Output':
            if (obj.Message != null) log(kindFor(obj.Status), obj.Message)
            break
        case 'ClearConsole':
            emit('clearconsole', {})
            break
        default:
            if (obj.Status !== undefined && obj.Message != null) log(kindFor(obj.Status), obj.Message)
    }
}

// ── Roblox process discovery / injection ────────────────────────────

function getRobloxProcesses() {
    return new Promise((resolve) => {
        if (process.platform !== 'win32') return resolve([])
        exec('tasklist /fi "imagename eq RobloxPlayerBeta.exe" /fo csv /nh', (err, stdout) => {
            if (err) return resolve([])
            const pids = []
            for (const line of stdout.split('\n')) {
                if (!line.trim() || line.includes('INFO: No tasks')) continue
                const parts = line.split('","')
                if (parts.length > 1) {
                    const pid = parseInt(parts[1], 10)
                    if (pid) pids.push(pid)
                }
            }
            resolve(pids)
        })
    })
}

function launchInjector(pid) {
    const injector = path.join(binDir(), 'Injector.exe')
    spawn(injector, [String(pid)], {
        cwd: binDir(),
        detached: true,
        stdio: 'ignore',
        windowsHide: true,
    }).unref()
}

async function attach() {
    if (!initialized) initialize()

    const injector = path.join(binDir(), 'Injector.exe')
    if (!fs.existsSync(injector)) {
        log('print', 'Downloading Cosmic binaries...')
        try { await setup() } catch (e) { return { success: false, error: 'Setup failed: ' + e.message } }
    }

    const pids = await getRobloxProcesses()
    if (pids.length === 0) return { success: false, error: 'No Roblox instance found' }

    const connected = new Set(clients.keys())
    const toInject = pids.filter(p => !connected.has(p))
    if (toInject.length === 0) return { success: false, error: 'All Roblox instances already injected' }

    let injected = 0
    for (const pid of toInject) {
        try { launchInjector(pid); injected++ }
        catch (e) { log('error', 'Failed to launch injector: ' + e.message) }
    }
    if (injected === 0) return { success: false, error: 'Failed to launch injector' }

    log('print', `Injecting into ${injected} instance(s)...`)
    return { success: true, injected }
}

// ── Execute / settings ──────────────────────────────────────────────

function broadcast(text) {
    let sent = 0
    for (const sock of clients.values()) {
        if (sock.readyState === WebSocket.OPEN) {
            try { sock.send(text); sent++ } catch {}
        }
    }
    return sent
}

function execute(script) {
    if (clients.size === 0) return { success: false, error: 'No clients connected' }
    const sent = broadcast(script)
    return sent > 0 ? { success: true } : { success: false, error: 'No open clients' }
}

function sendSetting(name, value) {
    // Booleans go out unquoted (matching the original wire format), everything else as a string.
    const payload = typeof value === 'boolean'
        ? JSON.stringify({ Name: name, Value: value })
        : JSON.stringify({ Name: name, Value: String(value) })
    broadcast(payload)
}

function status() {
    return { connected: clients.size > 0, clients: [...clients.keys()].map(pid => ({ pid })) }
}

// ── Auto-inject watcher ─────────────────────────────────────────────

function startAutoInjectLoop() {
    if (autoInjectTimer) return
    getRobloxProcesses().then(pids => { lastPids = new Set(pids) })

    autoInjectTimer = setInterval(async () => {
        const current = new Set(await getRobloxProcesses())

        if (autoInject) {
            const fresh = [...current].filter(p => !lastPids.has(p) && !injectedPids.has(p))
            for (const pid of fresh) {
                injectedPids.add(pid)
                try { launchInjector(pid) } catch {}
            }
        }

        for (const p of [...injectedPids]) if (!current.has(p)) injectedPids.delete(p)
        lastPids = current
    }, 2000)
}

// ── Plugin interface (called by the host) ───────────────────────────

module.exports = {
    activate(context) {
        ctx = context
        initialize()
        log('print', 'Cosmic API enabled - WebSocket server started.')
    },

    deactivate() {
        shutdown()
    },

    // Called when the host toggles one of the plugin's options.
    onOption(optId, value) {
        if (optId === 'autoInject') {
            autoInject = !!value
            log('print', `Auto-inject ${autoInject ? 'enabled' : 'disabled'}.`)
        } else if (optId === 'unlockFps') {
            sendSetting('Unlock-Fps', !!value)
        }
    },

    // The host routes the Attach button and Execute through this object.
    executor: {
        attach,
        execute,
        status,
    },
}

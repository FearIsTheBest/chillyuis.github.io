// ═══════════════════════════════════════════════════════════════════════════
//  Velocity API  -  Synapse executor plugin backed by VelocityApi.dll.
//
//  VelocityApi.dll is a managed .NET 10 assembly, so Node can't call it
//  directly. This plugin spawns the VelocityBridge sidecar (native/VelocityBridge,
//  published to ./bridge) and talks to it with newline-delimited JSON over
//  stdio. The host routes the Attach button / Execute through `executor`.
//
//  Flow:
//    activate()            -> spawns the bridge (VelAPI.StartCommunication)
//    executor.attach()     -> finds Roblox pids + VelAPI.Attach(pid) each
//    executor.execute(lua) -> VelAPI.Execute(lua, pid) for each attached pid
// ═══════════════════════════════════════════════════════════════════════════
'use strict'

const path = require('path')
const fs = require('fs')
const { spawn } = require('child_process')

// Default Velocity install location. Override via the "Velocity folder" option
// or the VELOCITY_DIR env var. The bridge runs with this as its cwd so Velocity
// can resolve/download its relative engine files (Bin\Decompiler.exe, etc.).
const DEFAULT_VELOCITY_DIR = 'C:\\Users\\Danny\\Downloads\\Velocity'
const REQUEST_TIMEOUT_MS = 30000

let ctx = null
let proc = null                 // the bridge child process
let ready = false               // bridge emitted {"event":"ready"}
let stdoutBuf = ''
let nextId = 1
const pending = new Map()       // id -> { resolve, reject, timer }
const injectedPids = new Set()  // pids we've successfully attached to
let velocityDir = DEFAULT_VELOCITY_DIR
let autoAttach = false
let autoTimer = null

function log(kind, msg) { if (ctx && ctx.log) ctx.log(kind, '[Velocity] ' + msg) }
function emit(event, data) { if (ctx && ctx.emit) ctx.emit(event, data) }

function bridgeExe() {
    return path.join(ctx.dir, 'bridge', process.platform === 'win32' ? 'VelocityBridge.exe' : 'VelocityBridge')
}

function resolveVelocityDir() {
    return (process.env.VELOCITY_DIR && process.env.VELOCITY_DIR.trim())
        || (velocityDir && velocityDir.trim())
        || DEFAULT_VELOCITY_DIR
}

// ── Bridge process lifecycle ────────────────────────────────────────────────

function spawnBridge() {
    if (proc) return
    const exe = bridgeExe()
    if (!fs.existsSync(exe)) {
        log('error', `Bridge not found at ${exe}. Build it: dotnet publish native/VelocityBridge -c Release -o plugins/velocity-api/bridge`)
        return
    }
    const cwd = resolveVelocityDir()
    log('print', `Starting bridge (cwd: ${cwd})`)

    proc = spawn(exe, [], { cwd, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] })

    proc.stdout.on('data', onStdout)
    proc.stderr.on('data', (d) => {
        const s = d.toString().trim()
        if (s) log('warn', s)
    })
    proc.on('error', (e) => log('error', `Bridge process error: ${e.message}`))
    proc.on('exit', (code) => {
        log('warn', `Bridge exited (code ${code})`)
        cleanupProc()
    })
}

function cleanupProc() {
    ready = false
    proc = null
    stdoutBuf = ''
    for (const [, p] of pending) { clearTimeout(p.timer); p.reject(new Error('bridge exited')) }
    pending.clear()
    const had = injectedPids.size > 0
    injectedPids.clear()
    if (had) emit('disconnected', {})
}

function killBridge() {
    if (autoTimer) { clearInterval(autoTimer); autoTimer = null }
    if (proc) { try { proc.kill() } catch {} }
    cleanupProc()
}

// ── Protocol: newline-delimited JSON over stdio ─────────────────────────────

function onStdout(chunk) {
    stdoutBuf += chunk.toString()
    let nl
    while ((nl = stdoutBuf.indexOf('\n')) !== -1) {
        const line = stdoutBuf.slice(0, nl).trim()
        stdoutBuf = stdoutBuf.slice(nl + 1)
        if (line) handleLine(line)
    }
}

function handleLine(line) {
    let msg
    try { msg = JSON.parse(line) } catch { return }

    if (msg.event) {
        switch (msg.event) {
            case 'ready': ready = true; log('print', 'Bridge ready.'); break
            case 'error': log('error', `${msg.a || 'Error'}: ${msg.b || ''}`); break
            case 'fatal': log('error', `Fatal: ${msg.error || ''}`); break
        }
        return
    }

    if (msg.id != null && pending.has(msg.id)) {
        const p = pending.get(msg.id)
        pending.delete(msg.id)
        clearTimeout(p.timer)
        p.resolve(msg)
    }
}

// Send a command and await its matching response.
function send(cmd, params = {}) {
    return new Promise((resolve, reject) => {
        if (!proc) { reject(new Error('bridge not running')); return }
        const id = nextId++
        const timer = setTimeout(() => {
            pending.delete(id)
            reject(new Error(`'${cmd}' timed out`))
        }, REQUEST_TIMEOUT_MS)
        pending.set(id, { resolve, reject, timer })
        try {
            proc.stdin.write(JSON.stringify({ id, cmd, ...params }) + '\n')
        } catch (e) {
            pending.delete(id)
            clearTimeout(timer)
            reject(e)
        }
    })
}

// Wait until the bridge has spawned and signalled ready (or time out).
async function ensureReady() {
    if (!proc) spawnBridge()
    if (!proc) throw new Error('bridge failed to start')
    if (ready) return
    const start = Date.now()
    while (!ready && Date.now() - start < 10000) {
        if (!proc) throw new Error('bridge exited during startup')
        await new Promise(r => setTimeout(r, 100))
    }
    if (!ready) throw new Error('bridge did not become ready')
}

// ── Roblox discovery / attach / execute ─────────────────────────────────────

async function robloxPids() {
    const res = await send('processes')
    return (res.processes || []).map(p => p.pid)
}

async function attach() {
    try {
        await ensureReady()
    } catch (e) {
        return { success: false, error: e.message }
    }

    let pids
    try { pids = await robloxPids() } catch (e) { return { success: false, error: e.message } }
    if (pids.length === 0) return { success: false, error: 'No Roblox instance found' }

    const toAttach = pids.filter(p => !injectedPids.has(p))
    if (toAttach.length === 0) return { success: false, error: 'All Roblox instances already attached' }

    let injected = 0
    let lastError = null
    for (const pid of toAttach) {
        try {
            const res = await send('attach', { pid })
            if (res.ok) {
                injectedPids.add(pid)
                injected++
                emit('connected', { pid })
                log('print', `Attached to PID ${pid} (${res.state}).`)
            } else {
                lastError = res.error || res.state || 'attach failed'
                log('warn', `Attach failed for PID ${pid}: ${lastError}`)
            }
        } catch (e) {
            lastError = e.message
            log('error', `Attach error for PID ${pid}: ${e.message}`)
        }
    }

    if (injected === 0) return { success: false, error: lastError || 'Failed to attach' }
    return { success: true, injected }
}

async function execute(script) {
    if (!proc || !ready) return { success: false, error: 'Not attached' }
    if (injectedPids.size === 0) return { success: false, error: 'Not attached to any Roblox instance' }

    let sent = 0
    let lastError = null
    for (const pid of [...injectedPids]) {
        try {
            const res = await send('execute', { pid, script })
            if (res.ok) sent++
            else { lastError = res.error || res.state; log('warn', `Execute failed on PID ${pid}: ${lastError}`) }
        } catch (e) {
            lastError = e.message
            log('error', `Execute error on PID ${pid}: ${e.message}`)
        }
    }

    if (sent === 0) return { success: false, error: lastError || 'No attached instance accepted the script' }
    return { success: true }
}

function status() {
    return { connected: injectedPids.size > 0, clients: [...injectedPids].map(pid => ({ pid })) }
}

// ── Auto-attach watcher ─────────────────────────────────────────────────────

function startAutoLoop() {
    if (autoTimer) return
    autoTimer = setInterval(async () => {
        if (!autoAttach || !proc || !ready) return
        try {
            const pids = await robloxPids()
            const fresh = pids.filter(p => !injectedPids.has(p))
            for (const pid of fresh) {
                const res = await send('attach', { pid })
                if (res.ok) { injectedPids.add(pid); emit('connected', { pid }); log('print', `Auto-attached PID ${pid}.`) }
            }
            // Drop pids whose Roblox process has closed.
            for (const p of [...injectedPids]) if (!pids.includes(p)) { injectedPids.delete(p) }
            if (injectedPids.size === 0) emit('disconnected', {})
        } catch { /* transient */ }
    }, 2500)
}

// ── Plugin interface (called by the host) ───────────────────────────────────

module.exports = {
    activate(context) {
        ctx = context
        spawnBridge()
        startAutoLoop()
        log('print', 'Velocity API enabled.')
    },

    deactivate() {
        killBridge()
        log('warn', 'Velocity API disabled.')
    },

    onOption(optId, value) {
        if (optId === 'velocityDir') {
            velocityDir = String(value || '').trim() || DEFAULT_VELOCITY_DIR
            log('print', `Velocity folder set to ${velocityDir}. Restarting bridge...`)
            killBridge()
            spawnBridge()
            startAutoLoop()
        } else if (optId === 'autoAttach') {
            autoAttach = !!value
            log('print', `Auto-attach ${autoAttach ? 'enabled' : 'disabled'}.`)
        }
    },

    // The host routes the Attach button and Execute through this object.
    executor: {
        attach,
        execute,
        status,
    },
}
